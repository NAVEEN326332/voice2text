// Speech Recognition setup (Web Speech API)
const recordBtn = document.getElementById('record-btn');
const speechText = document.getElementById('speech-text');
const copyBtn = document.getElementById('copy-btn');
const saveBtn = document.getElementById('save-btn');
const clearBtn = document.getElementById('clear-btn');

let recognition;
let isRecording = false;

// Check for browser support
if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = function(event) {
        let transcript = '';
        for (let i = 0; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
        }
        speechText.value = transcript;
    };

    recognition.onerror = function(event) {
        alert('Speech recognition error: ' + event.error);
        stopRecording();
    };
} else {
    recordBtn.disabled = true;
    recordBtn.textContent = "Speech Recognition Not Supported";
}

function startRecording() {
    recognition.start();
    isRecording = true;
    recordBtn.textContent = 'Stop Recording';
    recordBtn.classList.add('recording');
}

function stopRecording() {
    recognition.stop();
    isRecording = false;
    recordBtn.textContent = 'Start Recording';
    recordBtn.classList.remove('recording');
}

recordBtn.addEventListener('click', () => {
    if (!recognition) return;
    if (isRecording) {
        stopRecording();
    } else {
        startRecording();
    }
});

copyBtn.addEventListener('click', () => {
    speechText.select();
    document.execCommand('copy');
});

saveBtn.addEventListener('click', () => {
    const blob = new Blob([speechText.value], { type: "text/plain;charset=utf-8" });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = "speech.txt";
    link.click();
    URL.revokeObjectURL(link.href);
});

clearBtn.addEventListener('click', () => {
    speechText.value = '';
});